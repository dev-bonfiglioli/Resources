var genfuncs = app.CallFunction("common.GetGeneralFunctions")
var gentypes = app.CallFunction("common.GetGeneralTypes")
var conftypes = app.CallFunction("configurator.GetGeneralTypes")

var MSGID_REOPENCURWINDOW = "ReOpenCurWindow"   // da configurator.js!
var MSGID_STARTAUTOREFRESH = "StartAutoRefrsh"  // da configurator.js!

// get IPA from address, can be a string like "4096.2" or "0x1000.0x10"
function getIpa (address)
{
	if (typeof address == "string" && address.indexOf(".") > -1)
	{
		var indexes = address.split(".");
		idx = parseInt(indexes[0]);
		subidx = parseInt(indexes[1])
		return (subidx << 16) + idx;
	}
	else
		return parseInt(address);
}
var OBJ_FCUVERSION = '0x3803.1'
var OBJ_FCUNAME = '0x3908.1'
var OBJ_CMNAME = '0x3908.2'
var OBJ_IONAME = '0x3908.3'
var OBJ_SEMNAME = '0x3908.4'
var OBJ_ENCNAME = '0x3908.5'
var OBJ_ENCANAME = '0x3908.6'
// TODO for EM Dobule Axis var OBJ_ENC2NAME = '0x3908.7'

var OBJ_FWVERSION = '0x100A'
var OBJ_DEVICENAME = '0x1008'
var OBJ_ACTIVEDATASET = '0x4001'; //TODO get current active dataset object address

var IPA_FCUVERSION = getIpa(OBJ_FCUVERSION);
var IPA_FCUNAME = getIpa(OBJ_FCUNAME);
var IPA_CMNAME = getIpa(OBJ_CMNAME);
var IPA_IONAME = getIpa(OBJ_IONAME);
var IPA_SEMNAME = getIpa(OBJ_SEMNAME);
var IPA_ENCNAME = getIpa(OBJ_ENCNAME);
var IPA_ENCANAME = getIpa(OBJ_ENCANAME);
// TODO for EM Dobule Axis var IPA_FCUNAME = getIpa(OBJ_ENC2NAME);
var IPA_FWVERSION = getIpa(OBJ_FWVERSION);
var IPA_DEVICENAME = getIpa(OBJ_DEVICENAME);
var IPA_ACTIVEDATASET = getIpa(OBJ_ACTIVEDATASET);
var IPA_DEVICEDATA = 36;
var IPA_DEVICETYPE = 13;
var IPA_CONFIGURATION = 30;
			
// costanti per fso.OpenTextFile
var enuOpenTextFileModes = {
	ForReading: 1,
	ForWriting: 2,
	ForAppending: 8
}

// costanti per device Mapping
var AXIA_DEVICENAME_MAPPING = {
	P: 'Vert',
	V: 'Vert',
	A: 'Move',
	M: 'Move',
	S: 'Logic',
	L: 'Logic'
}
var AXIA_AXIS_MAPPING = {
	1: '',
	2: ' Double Axis'
}
var AXIA_DEVICENAME = 'Axia'
var AXIA_DEVICENAME_INFO_PREFIX = AXIA_DEVICENAME+'-'
var AXIA_AXIS_INFO_PREFIX = 'Axis:'
var AXIA_FCUNAME = 'HPC'
var AXIA_FCUNAME_INFO_PREFIX = AXIA_FCUNAME+'-'

var COLUMN_LABELS = { ipa: "Object", address: "Object" };

var UABUS_PORT_TCP = 17222;
var E_NOK = 1;


function Init()
{
}

function UpdateAlarmStatus()
{
}

function GetActiveDataSet(device)
{
	return device.GetParValue_ipa(IPA_ACTIVEDATASET);
}

function GetError(deviceLink)
{
	var err = deviceLink.ErrorCode;			// codice di errore interno a 16bit
	if (err == E_NOK && deviceLink.Protocol == "UABus")
		err = deviceLink.DeviceStatus;		// codice di errore esteso a 32bit ritornato dal target
	
	return err + ": " + deviceLink.ErrorString;
}

// funzione di caricamento custom di dati del parametro dal nodo xml. Aggiunge i <diffpar>
function CustomParameterLoad(par, parNode)
{
	var diffParNodelist = parNode.selectNodes("aggregation/diffpar");
	if (diffParNodelist.length == 0)
		return;
	
	par.diffPars = [];
	
	var diffParNode;
	while (diffParNode = diffParNodelist.nextNode())
	{
		var diffPar = {};
		
		var attr = diffParNode.getAttribute("visibilityMask");
		if (attr !== null)
			diffPar.visibilityMask = parseInt(attr);
		
		attr = diffParNode.getAttribute("devices");
		if (attr !== null)
			diffPar.devices = attr.split(",");
		
		attr = diffParNode.getAttribute("defval");
		if (attr !== null)
			diffPar.defaultValue = parseFloat(attr);
		
		attr = diffParNode.getAttribute("min");
		if (attr !== null)
			diffPar.min = parseFloat(attr);
		
		attr = diffParNode.getAttribute("max");
		if (attr !== null)
			diffPar.max = parseFloat(attr);
		
		par.diffPars.push(diffPar);
	}
}

// in base a devicedata+devicetype determina il device id bonfiglioli (usato poi nei diffpar)
function GetBonfiglioliDeviceID(device)
{
	var devicedata = device.GetParValue_ipa(IPA_DEVICEDATA);
	var devicetype = device.GetParValue_ipa(IPA_DEVICETYPE);
	
	var xpath = "//deviceinfo[@deviceid = '" + device.template.deviceID + "']/devices/device[@devicedata = '" + devicedata + "' and @devicetype = '" + devicetype + "']";
	var nodelist = app.CallFunction("catalog.Query", xpath);
	if (!nodelist || nodelist.length == 0)
		return;

	return nodelist[0].getAttribute("id");
}

// caricamento configurazione e applicazione visibilità e diffpar + stringhe  custom
function OnAfterLoadDevice(device, isNew)
{
	
	// se creazione nuovo device, applica i valori iniziali prendendoli dalla tempVar, in modo da pre-inizializzare i vari deviceID, configuration, ecc.
	if (isNew)
	{
		var initValues = app.TempVar("ANG_InitialValues");
		if (initValues)
			for (var ipa in initValues)
				device.SetParValue_ipa(ipa, initValues[ipa]);
	}
	
	// imposta la visibility del device partendo dalla configuration. questa operazione chiamerà la OnSetVisibilityMask che chiamerà la ApplyDiffPars,
	// che però uscirà immediatamente visto che il BonfiglioliDeviceID non è ancora stato impostato.
	// la ApplyDiffPars "definitiva" sarà chiamata poi sotto dopo.
	ApplyVisibilityFromCfg(device);
	
	device.BonfiglioliDeviceID = GetBonfiglioliDeviceID(device);
	
	// crea copia del template privata, per modifiche successive SOLO su questo device
	device.MakePrivateTemplate(true);
	
	var parList = device.template.parList;
	for (var i = 0; i < parList.length; i++)
	{
		var par = parList[i];
		
		// salva valori originali iniziali degli attributi. potrebbero venire modificati dalla ApplyDiffPars
		if (par.diffPars)
		{
			par.min_orig = par.min;
			par.max_orig = par.max;
			par.defaultValue_orig = par.defaultValue;
		}
	}
	
	AdjustDeviceSize(device);
	
	ApplyDiffPars(device, isNew);
}

function AdjustDeviceSize(device)
{
	if (!device.BonfiglioliDeviceID)
		return;
	
	// il size è la prima cifra del ID
	var deviceSize = parseInt(device.BonfiglioliDeviceID.substr(0, 1));
	
	// nasconde parametri specifici in base alla taglia
	device.template.parMap[416].hidden = (deviceSize < 4);	// Earth Fault Switch-Off Limit
		
	device.template.parMap[35].hidden  = (deviceSize < 8);	// No. of Freq. Inverters
	
	
	// nasconde valori di enum specifici in base alla taglia
	device.template.enums[4][16].hidden = (deviceSize > 4);	// "16 khz" da enum4, di "400  Switching Frequency"
	device.template.enums[5][16].hidden = (deviceSize > 4);	// "16 khz" da enum5, di "401  Min. Switching Frequency"
	
	device.template.enums[51][20].hidden = (deviceSize > 7);	// "20 - Mains: Shutdown" da enum51, di "576  Phase Supervision"
	device.template.enums[51][21].hidden = (deviceSize > 7);	// "21 - Mains &amp; Motor: Shutdown" da enum51, di "576  Phase Supervision"
}

// applicazione diffpar ai parametri attuali (essendo stata fatta la MakePrivateTemplate, sono modifiche al solo device corrente)
function ApplyDiffPars(device, isNew)
{
	var id = device.BonfiglioliDeviceID;
	if (!id)
		return;
	
	var visMask = 0;
	if (device.visibilityMask && device.visibilityMask.length != 0)
		// usa solo i primi 32bit
		visMask = device.visibilityMask[0];
	
	var parList = device.template.parList;
	for (var i = 0; i < parList.length; i++)
	{
		var par = parList[i];
		if (!par.diffPars)
			continue;

		var match = false;
		for (var j = 0; j < par.diffPars.length; j++)
		{
			var diffPar = par.diffPars[j];
			
			// visibilita e lista devices sono in AND (se specificati)
			if ((diffPar.visibilityMask === undefined || (diffPar.visibilityMask & visMask)) &&
				(diffPar.devices        === undefined || genfuncs.ArrayIndexOf(diffPar.devices, id) != -1))
			{
				if (diffPar.min !== undefined)
					par.min = diffPar.min;
				
				if (diffPar.max !== undefined)
					par.max = diffPar.max;
				
				if (diffPar.defaultValue !== undefined)
				{
					par.defaultValue = diffPar.defaultValue;
					// se siamo in creazione nuovo device, imposta subito il value al nuovo defaultValue
					if (isNew)
						for (var subidx = 0; subidx < par.subindexes; subidx++)
							device.SetParValue(par, par.defaultValue, false, subidx);
				}
				
				match = true;
				break;
			}
		}
		
		if (!match)
		{
			// ripristina attributi originali
			par.min = par.min_orig;
			par.max = par.max_orig;
			par.defaultValue = par.defaultValue_orig;
		}
		
		// se limiti non coincidenti e validi verifica che  min <= value <= max
		var min = undefined;
		if (par.min != undefined)
			min = app.CallFunction("configurator.ConvertValue", par.min, par.typePar);
			
		var max = undefined;
		if (par.max != undefined)
			max = app.CallFunction("configurator.ConvertValue", par.max, par.typePar);
		
		if (min != max)
		{
			for (var subidx = 0; subidx < par.subindexes; subidx++)
			{
				var value = device.GetParValue(par, subidx);
				if ((min !== undefined && value < min) || (max !== undefined && value > max))
				{
					var msg = app.Translate("Value out of range: ") + device.GetParTextValue(par, value);
					var msg2 = "min: " + device.GetParTextValue(par, min) + "   max: " + device.GetParTextValue(par, max);

					var subidxStr = "";
					if (par.subindexes > 1)
						subidxStr = "." + (subidx + (app.CallFunction("dllext.Get1basedSubIndex") ? 1 : 0));
				
					app.PrintMessage(par.name + " (" + par.ipa + subidxStr + ") : " + msg + "   " + msg2);
				}
			}
		}
	}
}

// verifica che tutti i valori di enum siano contenuti nell'insieme di valori corrispondenti (ad es. dopo un cambio visibilità)
function ValidateEnumValues(device)
{
	var parList = device.template.parList;
	for (var i = 0, t = parList.length; i < t; i++)
	{
		var par = parList[i];
		if (!device.CheckParVisibility(par))
			continue;    // parametro non visibile, ne ignora il valore
		
		if (par.typePar != conftypes.parTypes.Enum || par.writeonly)
			continue;    // parametro non enum o writeonly, nulla da verificare
		
		var curEnum = device.GetEnum(par.enumId);
		if (!curEnum)
			continue;   // anomalia, enum non trovato?
		
		for (var subidx = 0; subidx < par.subindexes; subidx++)
		{
			var value = device.GetParValue(par, subidx);
			var curEnumElem = curEnum[value];

			if (!curEnumElem || 
				curEnumElem.hidden || 
				(curEnumElem.visibilityMask !== null && !device.CheckVisibilityMask(curEnumElem.visibilityMask)))
			{
				var msg = app.Translate("Invalid enum value: ") + value;
				
				var subidxStr = "";
				if(par.subindexes > 1)
					subidxStr = "." + (subidx + (app.CallFunction("dllext.Get1basedSubIndex") ? 1 : 0));

				app.PrintMessage(par.name + " (" + par.ipa + subidxStr + ") : " + msg);
			}
		}
	}

}

function OnSetVisibilityMask(device)
{
	ApplyDiffPars(device, false);
	ValidateEnumValues(device);
}

// dato il valore di 'configuration' corrente imposta la visibilità associata
function ApplyVisibilityFromCfg(device, cfg)
{
	if (cfg === undefined)
		cfg = device.GetParValue_ipa(IPA_CONFIGURATION);
	
	var xpath = "//deviceinfo[@deviceid = '" + device.template.deviceID + "']/configurations/configuration[@id = " + cfg + "]";
	var nodelist = app.CallFunction("catalog.Query", xpath);
	if (!nodelist || nodelist.length == 0)
		return;

	var visMask = parseInt(nodelist[0].getAttribute("visibilityMask"));
	device.SetVisibilityMask(visMask);
}


// dato il valore di 'module' e capbability corrente imposta la visibilità associata
function ApplyVisibilityFromModulesAndCapabilities(device)
{
	// TODO for capability. We have not the object

	device.ReadPar(IPA_FCUNAME, false, true)
	device.ReadPar(IPA_CMNAME, false, true)
	device.ReadPar(IPA_IONAME, false, true)
	device.ReadPar(IPA_SEMNAME, false, true)
	device.ReadPar(IPA_ENCNAME, false, true)
	device.ReadPar(IPA_ENCANAME, false, true)

	var current_modules = []; // contains the module present for each slot 6
	current_modules.push(device.GetParValue_ipa(IPA_FCUNAME))
	current_modules.push(device.GetParValue_ipa(IPA_CMNAME))
	current_modules.push(device.GetParValue_ipa(IPA_IONAME))
	current_modules.push(device.GetParValue_ipa(IPA_SEMNAME))
	current_modules.push(device.GetParValue_ipa(IPA_ENCNAME))
	current_modules.push(device.GetParValue_ipa(IPA_ENCANAME))
	var current_capabilities = []; // contains the capabilities present TODO

	var modules_capabilities_visibility = []; // contains the module present for each slot 6 and capabilities
	// loop over current modules and get the visibility mask
	for (var i = 0; i < current_modules.length; i++)
	{
		var xpath = "//deviceinfo[@deviceid = '" + device.template.deviceID + "']/modules/module[@id = " + current_modules[i] + "]";
		modules_capabilities_visibility.push(app.CallFunction("catalog.Query", xpath));
	}
	// loop over current capabilities and get the visibility mask
	for (var i = 0; i < current_capabilities.length; i++)
	{
		var xpath = "//deviceinfo[@deviceid = '" + device.template.deviceID + "']/capabilities/capability[@id = " + current_capabilities[i] + "]";
		modules_capabilities_visibility.push(app.CallFunction("catalog.Query", xpath));
	}
	var vis_mask = [0,0,0,0];
	var is_mask_set = false;
	// loop over the retrieved visibility masks and calculate the final one
	for (var i = 0; i < modules_capabilities_visibility.length; i++)
	{
		var nodelist = modules_capabilities_visibility[i];
		if (nodelist && nodelist.length > 0){
			var masks = nodelist[0].getAttribute("visibilityMask").split(",");
			for (var j = 0; j < masks.length; j++)
			{
				is_mask_set = true;
				vis_mask[j]+=parseInt(masks[j]);
			}
		}
	}
	if (is_mask_set)
	{
		device.SetVisibilityMask(vis_mask.join(','));
	}
}

function OnAfterReadChangedConfiguration(uniqueID, ipa, value, oldvalue)
{
	var device = app.CallFunction("configurator.GetDevice", uniqueID);
	ApplyVisibilityFromCfg(device, value);
}

function OnChangeConfiguration(uniqueID, ipa, value)
{
	var device = app.CallFunction("configurator.GetDevice", uniqueID);
	ApplyVisibilityFromCfg(device, value);
	return value;
}

var m_reboot_autoRefreshState = false;

function OnBeforeWriteReboot(uniqueID, ipa, value)
{
	// il cambio di configurazione in auto-refresh causa troppi problemi:
	// sia la pagina che l'albero vengono rinfrescati, e la scrittura causa il reboot
	// come workaround disabilita qui autorefresh
	if (app.CallFunction("configurator.IsAutoRefresh"))
	{
		m_reboot_autoRefreshState = true;
		app.CallFunction("configurator.StopAutoRefresh")
	}
		
	return value
}

function OnAfterWriteReboot(uniqueID, ipa, value)
{
	OnCatchTargetReboot(uniqueID, ipa, value);
	
	if (m_reboot_autoRefreshState)
	{
		app.SendMessage(MSGID_STARTAUTOREFRESH, null, false);
		m_reboot_autoRefreshState = false;
	}
}

function UpdateActiveDatasetInMonitor(currentDataSet)
{
	var list = app.CallFunction("dllext.GetMonitorList");
	if (list === undefined || list === null)
		return;
	
	list = genfuncs.FromSafeArray(list);
	if( !list || list.length == 0)
		return;
	
	for (var i = 0; i < list.length; i++)
	{
		var arr = list[i].split("|");
		var uniqueID = arr[0];
		var ipa = arr[1];
		var subidx = arr[2];
		
		var device = app.CallFunction("configurator.GetDevice", uniqueID);
		if(!device)
			continue;
		
		var par = device.GetParTemplate(ipa);
		if (!par)
			continue;
		
		// se parametro 'index' o scalare non fa nulla
		if (par.isIndexed || par.subindexes <= 1)
			continue;
		
		if (subidx != currentDataSet)
			app.CallFunction("dllext.ReplaceSubidxInMonitor", uniqueID, ipa, subidx, currentDataSet);
	}
}

function UpdateActiveDatasetInGraph(currentDataSet)
{
	// -------- aggiornamento dataset nella graph
	var list = app.CallFunction("graph__sink.GetTracksList");
	if (!list || list.length == 0)
		return;
	
	for (var i = 0; i < list.length; i++)
	{
		var uniqueID = list[i].uniqueID;
		var ipa = list[i].ipa;
		var subidx = list[i].subidx;
		
		var device = app.CallFunction("configurator.GetDevice", uniqueID);
		if(!device)
			continue;
		
		var par = device.GetParTemplate(ipa);
		if (!par)
			continue;
		
		// se parametro 'index' o scalare non fa nulla
		if (par.isIndexed || par.subindexes <= 1)
			continue;
		
		if (subidx != currentDataSet)
			app.CallFunction("graph__sink.ReplaceSubidxInGraph", uniqueID, ipa, subidx, currentDataSet);
	}
}

function OnAfterReadDataSet(uniqueID, ipa, value)
{
	app.PrintMessage("Active dataset changed to " + value);
	if(value < 0)
		return;
	
	// il dataset è 1..4, riporta il subidx 0-based
	var currentDataSet = value - 1;
	
	UpdateActiveDatasetInMonitor(currentDataSet);
	UpdateActiveDatasetInGraph(currentDataSet);
	
	app.CallFunction("dllext.RunRefreshThread")
}

function RecalcBonfiglioliDeviceID(device, quiet)
{
	var newBonfiglioliDeviceID = GetBonfiglioliDeviceID(device);
	if (device.BonfiglioliDeviceID != newBonfiglioliDeviceID)
	{
		if (quiet || app.MessageBox(app.Translate("Device size or type has changed.\nUpdate current project?"), "", gentypes.MSGBOX.MB_OKCANCEL|gentypes.MSGBOX.MB_ICONEXCLAMATION) == gentypes.MSGBOX.IDOK)
		{
			device.BonfiglioliDeviceID = newBonfiglioliDeviceID;
			
			AdjustDeviceSize(device);
			ApplyDiffPars(device, false);
			ValidateEnumValues(device);
		}
	}
}

function onConnect(device)
{
	// TODO identificazione
	// lettura di devicedata+devicetype per verificare se taglia/size ecc per caso sono cambiati (determinano il "bonfiglioli device id")
/*	if (!device.ReadPar(IPA_DEVICEDATA, false, true))
		return;
	if (!device.ReadPar(IPA_DEVICETYPE, false, true))
		return;
	
	RecalcBonfiglioliDeviceID(device, false);*/
	
	if (!CheckSSLCertificate(device))
		return false;
	
	ApplyVisibilityFromModulesAndCapabilities(device)
	
	app.OpenWindow("SyncDevicesPage", app.Translate("Sync action"), "");
	var action = app.TempVar("SyncDevices_action");
	app.TempVar("SyncDevices_action") = undefined;
	
	var devices = app.CallFunction("configurator.GetAllDevices");	
	for (var i in devices)
	{
		if(action == 1) // WR all
			devices[i].WriteAll(false, false);
		else if(action == 2) // RD ALL
			devices[i].ReadAll()
	}
	
	return true;
}


function OnCatchTargetReboot(uniqueID, ipa, value)
{
	var device = app.CallFunction("configurator.GetDevice", uniqueID);
	device.WaitUntilReboot();	
}

function Reset(device, quiet)
{
	var res = true;
	app.CallFunction("dllext.LockComm");
	try
	{
		device.deviceLink.Reset_Command();
	}
	catch (e)
	{ 
		// errore TMO unico ammesso
		if (!device.deviceLink.ErrTimeOut)
		{
			res = false;
			app.PrintMessage(app.Translate("Error on Reset") + " " + GetError(device.deviceLink));
		}
	}
	
	if(res)
		res = device.WaitUntilReboot();
	
	app.CallFunction("dllext.UnlockComm");
	
	return res;
}

function ResetError(device, quiet)
{
	var res = true;
	app.CallFunction("dllext.LockComm");
	try
	{
		// aggiunto numero dell'asse (?)
		device.deviceLink.ResetError(0);
	}
	catch (e)
	{ 
		// errore TMO unico ammesso
		if (!device.deviceLink.ErrTimeOut)
		{
			res = false;
			app.PrintMessage(app.Translate("Error on Reset Errors") + " " + GetError(device.deviceLink));
		}
	}
	
	if(res)
		res = device.WaitUntilReboot();
	
	app.CallFunction("dllext.UnlockComm");
	
	return res;
}

function RestoreDefaults(device, quiet)
{
	app.TempVar("Restore_filter") = undefined;
	// scelta dei filtri tramite apposita pagina HTML
	app.OpenWindow("ChooseRestoreFilter", app.Translate("Restore filter"), "");
	var filter = app.TempVar("Restore_filter");
	app.TempVar("Restore_filter") = undefined;
	
	if(filter === undefined)
		return false;
	
	var res = true;
	app.CallFunction("dllext.LockComm")
	try
	{
		device.deviceLink.Restore_Command(filter);		
	}
	catch (e)
	{ 
		// errore TMO unico ammesso
		if (!device.deviceLink.ErrTimeOut)
		{
			res = false;
			app.PrintMessage(app.Translate("Error on Restore values") + " " + GetError(device.deviceLink));
		}
	}
	
	if(res)
		res = device.WaitUntilReboot();
	
	app.CallFunction("dllext.UnlockComm");
	
	return res;
}

function GetCustomColumnLabels()
{
	return COLUMN_LABELS;
}

function OnBeforeReadAll(device)
{
	// lettura immediata del parametro 30=configuration prima della read all, per aggiornare tutte le visibilità e leggere quindi i parametri corretti poi
	device.ReadPar(IPA_CONFIGURATION, false);
	return true;
}

function OnAfterReadAll(device)
{
	if (app.CallFunction("configurator.IsGridPage", app.GetCurrentWindowName()))
	{
		// se si è su una griglia la riapre, la visibilità dei par potrebbe essere cambiata
		// fatto con msg ritardato, perchè se chiamato dentro script griglia darebbe errore
		// NB: questa stessa cosa è già fatta dalla OnBeforeReadAll (se cambia la cfg da OnAfterReadChangedConfiguration),
		// ma per ragioni non note il msg ritardato lanciato da Device.SetVisibilityMask si perde durante la read all.... (?)
		app.SendMessage(MSGID_REOPENCURWINDOW, null, false)
	}
}

function ReadScanInfo(device)
{
	var versionParam = IPA_FWVERSION;
	if (!device.ReadPar(versionParam, false, true)){
		versionParam = IPA_FCUVERSION;
		if (!device.ReadPar(versionParam, false, true))
			return;
	}

	var result = {};

	// get the version
	result.version = device.GetParValue_ipa(versionParam);

	if (result.version){
		if (result.version.indexOf("V") > -1)
		{
			var versionList = result.version;
			if (versionList.indexOf(" ") > -1)
			{
				versionList = versionList.split(" ")[0]
			}

			versionList = versionList.split("V")
			if (versionList.length==1){
				versionList = versionList[0].split(".")
			}else{
				versionList = versionList[1].split(".")
			}
			result.version = ''
			for (var i = 0; i < versionList.length; i++){
				result.version += parseInt(versionList[i],10).toString()
				if (i<(versionList.length-1)){
					result.version += '.'
				}
			}
		}
	}

	// get the name
	try {
		device.ReadPar(IPA_DEVICENAME, false, true)
		var deviceName = device.GetParValue_ipa(IPA_DEVICENAME);
		var deviceNameInfoIndex = deviceName.indexOf(AXIA_DEVICENAME_INFO_PREFIX)
		if (deviceNameInfoIndex >= 0){
			result.name = AXIA_DEVICENAME + ' ' + AXIA_DEVICENAME_MAPPING[deviceName.substr(deviceNameInfoIndex+AXIA_DEVICENAME_INFO_PREFIX.length,1)];
		}
		var axisInfoIndex = deviceName.indexOf(AXIA_AXIS_INFO_PREFIX)
		if (axisInfoIndex >= 0){
			result.name += AXIA_AXIS_MAPPING[deviceName.substr(axisInfoIndex+AXIA_AXIS_INFO_PREFIX.length,1)]
		}
	} catch (error) {
		app.PrintMessage(app.Translate("Warning on getting device name: ") + error.message);
		// Trying with another Object IPA_FCUNAME
		try {
			device.ReadPar(IPA_FCUNAME, false, true)
			var deviceName = device.GetParValue_ipa(IPA_FCUNAME);
			var deviceNameInfoIndex = deviceName.indexOf(AXIA_FCUNAME_INFO_PREFIX)
			if (deviceNameInfoIndex >= 0){
				result.name = AXIA_DEVICENAME + ' ' + AXIA_DEVICENAME_MAPPING[deviceName.substr(deviceNameInfoIndex+AXIA_FCUNAME_INFO_PREFIX.length,1)];
			}
			var axisInfoIndex = deviceName.indexOf(AXIA_AXIS_INFO_PREFIX)
			if (axisInfoIndex >= 0){
				result.name += AXIA_AXIS_MAPPING[deviceName.substr(axisInfoIndex+AXIA_AXIS_INFO_PREFIX.length,1)]
			}
		} catch (error) {
			app.PrintMessage(app.Translate("Warning on getting fcu name: ") + error.message);
			result.name = 'Axia Vert'; //TODO modify to have the right device name identification object 
		}
	}

	return result;
}

// per parametri (read only) da gestire però come enum stringa->stringa (caso eccezionale)
function StringEnum_ValueToText(uniqueID, ipa, value)
{
	var device = app.CallFunction("configurator.GetDevice", uniqueID);
	if (!device)
		return "?";
	
	var par = device.GetParTemplate(ipa);
	if (!par || !par.options.stringEnumId)
		return "?";
	
	// gli enum in realtà hanno chiavi stringa->stringa essendo mappe js...
	var en = device.GetEnum(par.options.stringEnumId);
	if (!en)
		return "?";
		
	var enumElem = en[value];
	if (enumElem)
		return enumElem.descr;
	else
		return value;
}

// To manage the standard TCP/IP format for read and write
function OnValueToIP(uniqueID, ipa, value)
{
	return (value & 0xFF) + "." + ((value >> 8) & 0xFF) + "." + ((value >> 16) & 0xFF) + "." + ((value >> 24) & 0xFF);
}

function OnIPToValue(uniqueID, ipa, text)
{
	var result = 0;
	try
	{
	   var arr = text.split(".");
	   result = (parseInt(arr[0])) + (parseInt(arr[1]) << 8) + (parseInt(arr[2]) << 16) + (parseInt(arr[3]) << 24);	
	}
	catch (e)
	{ 
	}
    return result;
}
 
//To Manager Visible String formatting
function OnVisibleStringToString(uniqueID, ipa, value)
{
	var result = '';
	try
	{
		result = value.substr(1);
	}
	catch (e)
	{ 
	}
    return result;
}

function OnStringToVisibleString(uniqueID, ipa, text)
{
	var result = String.fromCharCode(0);
	try
	{
		result = String.fromCharCode(text.length)+text;	
	}
	catch (e)
	{ 
	}
    return result;
}

//To Manager Float String formatting
function OnFloatToString(uniqueID, ipa, value)
{
	var result = '';
	try
	{
		result = genfuncs.sprintf("%.6f", value).match(/^-?\d*\.?0*\d{0,4}/)[0].replace(/(\.[0-9]*[1-9])0+$|\.0*$/,'$1');
	}
	catch (error)
	{
		app.PrintMessage(app.Translate("Error on float conversion: ") + error.message);
	}
    return result;
}

function IsSSL(objCommstring)
{
	return objCommstring.protocol == "UABus" && objCommstring.portType == "TCPIP" && objCommstring.lineConf.slice(-4) == ",SSL";
}

function Date2Secs(d)
{
	return parseInt(d.getTime() / 1000);
}

function Secs2Date(s)
{
	return new Date(s * 1000);
}

function OnConnectionError(device, hresult, errCode)
{
	// verifica se tentativo di connessione SSL
	var strCommstring = device.GetCommString();
	var objCommstring = app.CallFunction("common.SplitCommString", strCommstring);
	if (IsSSL(objCommstring))
	{
		// ricostruisce stringa per connessione TCP normale non SSL
		objCommstring.portNum = UABUS_PORT_TCP;
		objCommstring.lineConf = objCommstring.lineConf.slice(0,-4);
		//objCommstring.address = "10.0.0.79";   //DEBUG
		strCommstring = app.CallFunction("common.BuildCommString2", objCommstring);
		
		try
		{
			device.devLinkMng.Open(strCommstring);
		}
		catch (ex)
		{
			// fallita pure connessione TCP, niente da fare
			return;
		}
		
		var deviceLink = device.devLinkMng.DeviceLink_AddRef;
		var msg = app.Translate("Can not connect to %1 using SSL, but succeeded without SSL: certificate is probably missing");
		app.PrintMessage(genfuncs.FormatMsg(msg, objCommstring.address));

		RenewCertificate(deviceLink);
		
		deviceLink.Close();
		return false;
	}
}

function RenewCertificate(deviceLink)
{
	// generazione certificato valido un anno da ora. oppure chiedere all'utente?
	var startDate = new Date();
	var endDate = new Date();
	endDate.setYear(endDate.getYear() + 1);

	var msg = app.Translate("Generating SSL certificate from '%1' to '%2' ...");
	app.PrintMessage(genfuncs.FormatMsg(msg, startDate.toLocaleString(), endDate.toLocaleString()));
	app.CallFunction("dllext.LockComm");
	try
	{
		deviceLink.CreateCertificate(Date2Secs(startDate), Date2Secs(endDate));
		app.PrintMessage(app.Translate("Certificate successfully created. Please wait a while and try to reconnect"));
		// non si sa quanto ci mette a farlo...
	}
	catch (ex)
	{
		app.CallFunction("dllext.UnlockComm");
		app.PrintMessage(app.Translate("Error Creating certificate: ") + GetError(deviceLink));
		return false;
	}
	app.CallFunction("dllext.UnlockComm");
	return true;
}

function CheckSSLCertificate(device)
{
	var strCommstring = device.GetCommString();
	var objCommstring = app.CallFunction("common.SplitCommString", strCommstring);
	if (IsSSL(objCommstring))
	{
		var startDate = Secs2Date(device.deviceLink.SSLCertNotBefore);
		var endDate   = Secs2Date(device.deviceLink.SSLCertNotAfter);
		
		var msg = app.Translate("SSL connection OK: certificate valid from '%1' to '%2'");
		app.PrintMessage(genfuncs.FormatMsg(msg, startDate.toLocaleString(), endDate.toLocaleString()));
		
		var now = new Date();
		if (now < startDate || now > endDate)
		{
			var msg = genfuncs.FormatMsg(app.Translate("WARNING: SSL certificate is expired!\n\nfrom: %1\nto: %2\n\nConnect anyway and automatically renew the certificate?\n(No=connect without renew)"), startDate.toLocaleString(), endDate.toLocaleString());
			var ris = app.MessageBox(msg, "", gentypes.MSGBOX.MB_YESNOCANCEL|gentypes.MSGBOX.MB_ICONEXCLAMATION);
			switch (ris)
			{
				case gentypes.MSGBOX.IDYES:
					RenewCertificate(device.deviceLink);
					return false;
				case gentypes.MSGBOX.IDNO:
					return true;
				default:
					return false;
			}
		}
	}
	
	return true;
}
